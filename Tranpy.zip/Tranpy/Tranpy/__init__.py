import tranpy
tranpy.translate("Hello World")